// import express from "express";
// import {
//   razorpayWebhook,
//   createOrder,
// } from "../controller/paymentController.js";

// const router = express.Router();

// router.post(
//   "/webhook",
//   express.raw({ type: "application/json" }),
//   razorpayWebhook
// );
// router.post("/create-order", createOrder);

// export default router;
